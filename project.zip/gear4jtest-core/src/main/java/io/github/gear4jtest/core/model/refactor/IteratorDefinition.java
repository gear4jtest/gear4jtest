package io.github.gear4jtest.core.model.refactor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;

public class IteratorDefinition<IN, OUT> extends AbstractOperationDefinition<IN, OUT> {

	private Function<IN, ? extends Iterable<?>> func;
	private AssemblyLineDefinition assemblyLineDefinition;
	private AbstractOperationDefinition operation;
	private Accumulator accumulator;
	private Collector collector;

	private IteratorDefinition(String id) {
		super(id);
	}

	public Function<IN, ? extends Iterable<?>> getFunc() {
		return func;
	}

	public Accumulator getAccumulator() {
		return accumulator;
	}

	public Collector getCollector() {
		return collector;
	}

	@Override
	public OUT execute(IN input, ExecutionContext context, OperationExecution operationExecution) throws Exception {
		Iterable<?> collection = null;
		if (func != null) {
			collection = func.apply(input);
		} else {
			collection = (Iterable<?>) input;
		}
		Collection<Object> results = new ArrayList<>();
		for (Object element: collection) {
			var result = operation.run(element, context);

			operationExecution.getReport().addSubOperationReport(result.getReport());

			if (result.getReport().getStatus() == OperationExecution.OperationReport.Status.FAILED) {
				return null;
			}

			results.add(result.getResult());
		}

//		if (accumulator != null) {
//			Collection<?> acc = accumulator.getCollectionSupplier().getSupplier().get();
//			results.forEach(r -> {
//				if (r.isSuccess()) {
//					acc.add(r.getResult());
//				} else {
//					report.addError(r.getError());
//				}
//			});
		if (collector != null) {
			return (OUT) results.stream().collect(collector);
		} else {
			return (OUT) results;
		}
//		}
//		return new ExecutionResult<>((OUT) results, true, null, report);
	}

	public static class Builder<IN, OUT> {

		private final IteratorDefinition<IN, OUT> managedInstance;

		public Builder(String id) {
			managedInstance = new IteratorDefinition<>(id);
		}

		public <A> Builder<IN, A> iterableFunction(Function<IN, ? extends Iterable<A>> func) {
			managedInstance.func = func;
			return (Builder<IN, A>) this;
		}

		public <A> Builder<IN, A> pipeline(AssemblyLineDefinition<OUT, A> assemblyLineDefinition) {
			managedInstance.assemblyLineDefinition = assemblyLineDefinition;
			return (Builder<IN, A>) this;
		}

		public <A> Builder<IN, A> operation(AbstractOperationDefinition<OUT, A> assemblyLineDefinition) {
			managedInstance.operation = assemblyLineDefinition;
			return (Builder<IN, A>) this;
		}

		public Builder<IN, OUT> accumulator(Accumulator accumulator) {
			managedInstance.accumulator = accumulator;
			return this;
		}

		public <C> Builder<IN, C> collector(Collector<OUT, ?, C> collector) {
			managedInstance.collector = collector;
			return (Builder<IN, C>) this;
		}

		public IteratorDefinition<IN, OUT> build() {
			return managedInstance;
		}

	}

	public static class Accumulator {
		
		private final CollectionSupplier collectionSupplier;
		
		public Accumulator(CollectionSupplier collectionSupplier) {
			this.collectionSupplier = collectionSupplier;
		}

		public CollectionSupplier getCollectionSupplier() {
			return collectionSupplier;
		}

		public enum CollectionSupplier {
			LIST(ArrayList::new),
			SET(HashSet::new);

			private final Supplier<Collection<?>> supplier;

			private CollectionSupplier(Supplier<Collection<?>> supplier) {
				this.supplier = supplier;
			}

			public Supplier<Collection<?>> getSupplier() {
				return supplier;
			}

		}

	}

	public static class ListAccumulator extends Accumulator {

		public ListAccumulator() {
			super(CollectionSupplier.LIST);
		}
		
	}

	public static class SetAccumulator extends Accumulator {

		public SetAccumulator() {
			super(CollectionSupplier.SET);
		}
		
	}

}
