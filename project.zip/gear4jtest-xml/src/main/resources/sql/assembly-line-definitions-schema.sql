CREATE TABLE assembly_line_definitions (
    id VARCHAR(255) PRIMARY KEY,
    assembly_line_id VARCHAR(255) NOT NULL,
    version VARCHAR(255) NOT NULL,
    content VARCHAR(255) NOT NULL,
    created TIMESTAMP NOT NULL,
    creator VARCHAR5(255),
    CONSTRAINT UK_assembly_line_id_version UNIQUE (assembly_line_id, version)
);
