package io.test.gear4test.xml.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import io.test.gear4test.xml.classloader.InMemoryClassLoader;
import io.test.gear4test.xml.manager.AssemblyLineManager.ExecutionMode;

public class ClassLoaderRegistry {
    private static final ClassLoaderRegistry INSTANCE = new ClassLoaderRegistry();
    private final Map<String, InMemoryClassLoader> classLoaders = new ConcurrentHashMap<>();
    
    private ClassLoaderRegistry() {}
    
    public static ClassLoaderRegistry getInstance() {
        return INSTANCE;
    }
    
    /**
     * Enregistre un ClassLoader
     */
    public void registerClassLoader(String chainId, String version, ExecutionMode mode, InMemoryClassLoader classLoader) {
        String key = buildKey(chainId, version, mode);
        classLoaders.put(key, classLoader);
    }
    
    /**
     * Libère un ClassLoader spécifique
     */
    public boolean unregisterClassLoader(String chainId, String version, ExecutionMode mode) {
        String key = buildKey(chainId, version, mode);
        InMemoryClassLoader removed = classLoaders.remove(key);

        if (removed != null) {
            // Nettoyage du ClassLoader si nécessaire
            // (ici on pourrait appeler une méthode de nettoyage sur le compilateur)
            return true;
        }
        return false;
    }
    
    /**
     * Libère tous les ClassLoaders d'une chaîne d'opération
     */
    public void unregisterAllVersions(String chainId) {
        List<String> keysToRemove = new ArrayList<>();
        classLoaders.keySet().stream()
            .filter(key -> key.startsWith(chainId + ":"))
            .forEach(keysToRemove::add);
        
        keysToRemove.forEach(classLoaders::remove);
    }
    
    /**
     * Vide complètement le registre
     */
    public void clear() {
        classLoaders.clear();
    }
    
    /**
     * Retourne le nombre de ClassLoaders enregistrés
     */
    public int size() {
        return classLoaders.size();
    }
    
    private String buildKey(String chainId, String version, ExecutionMode mode) {
        return String.format("%s:%s:%s", chainId, version, mode);
    }
}