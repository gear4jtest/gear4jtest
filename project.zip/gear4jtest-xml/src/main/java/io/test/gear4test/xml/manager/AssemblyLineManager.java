package io.test.gear4test.xml.manager;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.squareup.javapoet.JavaFile;
import io.github.gear4jtest.core.model.refactor.AssemblyLineDefinition;
import io.test.gear4test.xml.classloader.InMemoryClassLoader;
import io.test.gear4test.xml.compiler.FinalRealJDTInMemoryCompiler;
import io.test.gear4test.xml.generator.GeneratedAssemblyLine;
import io.test.gear4test.xml.generator.XmlToJavaGeneratorV4;
import io.test.gear4test.xml.persistence.OperationChainRepository;

/**
 * Service principal de gestion des chaînes d'opérations
 */
public class AssemblyLineManager {

    private final OperationChainRepository repository;
    private final XmlToJavaGeneratorV4 translator;
    private final DependencyInjector dependencyInjector;
    private final Map<String, CachedOperationChain> cache;
    private final ReadWriteLock cacheLock;

    public AssemblyLineManager(OperationChainRepository repository,
                               XmlToJavaGeneratorV4 translator,
                               DependencyInjector dependencyInjector) {
        this.repository = repository;
        this.translator = translator;
        this.dependencyInjector = dependencyInjector;
        this.cache = new ConcurrentHashMap<>();
        this.cacheLock = new ReentrantReadWriteLock();
    }

    /**
     * Récupère une instance de chaîne d'opération à partir de son identifiant
     */
    public <IN, OUT> AssemblyLineDefinition<IN, OUT> getOperationChain(String chainId, String version, ExecutionMode mode, boolean shouldCache)
            throws OperationChainException {
        String cacheKey = buildCacheKey(chainId, version, mode);

        if (shouldCache) {
            cacheLock.readLock().lock();
            try {
                CachedOperationChain cached = cache.get(cacheKey);
                if (cached != null && !cached.isExpired()) {
                    return (AssemblyLineDefinition<IN, OUT>) cached.getInstance();
                }
            } finally {
                cacheLock.readLock().unlock();
            }
        }

        cacheLock.writeLock().lock();
        try {
            if (shouldCache) {
                CachedOperationChain cached = cache.get(cacheKey);
                if (cached != null && !cached.isExpired()) {
                    return (AssemblyLineDefinition<IN, OUT>) cached.getInstance();
                }
            }

            Optional<String> xmlContent = repository.getOperationChainXml(chainId, version, mode);
            if (xmlContent.isEmpty()) {
                throw new OperationChainException(
                        String.format("Chaîne d'opération non trouvée: %s v%s (%s)", chainId, version, mode)
                );
            }

            // Compilation et création de l'instance
            GeneratedAssemblyLine instance = compileAndCreateInstance(xmlContent.get(), chainId, version, mode);
            AssemblyLineDefinition<IN, OUT> assemblyLineDefinition = instance.getAssemblyLineDefinition();

            // Mise en cache
            if (shouldCache) {
                CachedOperationChain cachedChain = new CachedOperationChain(
                        assemblyLineDefinition,
                        chainId,
                        version,
                        mode,
                        LocalDateTime.now()
                );
                cache.put(cacheKey, cachedChain);
            }

            return assemblyLineDefinition;

        } finally {
            cacheLock.writeLock().unlock();
        }
    }

//    /**
//     * Crée une instance de chaîne d'opération directement à partir du contenu XML
//     */
//    public <T> T createOperationChainFromXml(String xmlContent) throws OperationChainException {
//
//        return compileAndCreateInstance(xmlContent, "direct", "1.0", ExecutionMode.TEST);
//    }

    /**
     * Compile et crée une instance de chaîne d'opération
     */
    private GeneratedAssemblyLine compileAndCreateInstance(String xmlContent, String chainId, String version, ExecutionMode mode)
            throws OperationChainException {

        try {
            Path file = Paths.get("the-file-name.txt");
            Files.write(file, List.of(xmlContent), StandardCharsets.UTF_8);
            JavaFile javaCode = translator.generateFromAssemblyLine(file.toFile());

            // 2. Compilation
            FinalRealJDTInMemoryCompiler compiler = new FinalRealJDTInMemoryCompiler();
            Map<String, byte[]> compilationSuccess = compiler.compileFromString(javaCode.typeSpec.name, javaCode.toString());

            if (compilationSuccess.isEmpty()) {
                throw new OperationChainException("Erreur de compilation de la chaîne d'opération: " + chainId);
            }

            // 3. Chargement de la classe
            InMemoryClassLoader classLoader = new InMemoryClassLoader();
            classLoader.addCompiledClasses(compilationSuccess);
            Class<?> operationChainClass = classLoader.loadClass(javaCode.typeSpec.name);

            // 4. Création de l'instance
            GeneratedAssemblyLine rawInstance = (GeneratedAssemblyLine) operationChainClass.getDeclaredConstructor().newInstance();

            // 5. Injection des dépendances
            dependencyInjector.injectDependencies(rawInstance, mode);

            // 6. Sauvegarde du ClassLoader pour nettoyage ultérieur
            ClassLoaderRegistry.getInstance().registerClassLoader(chainId, version, mode, classLoader);

            return rawInstance;

        } catch (Exception e) {
            throw new OperationChainException("Erreur lors de la création de la chaîne d'opération", e);
        }
    }

    /**
     * Purge le cache pour une chaîne d'opération spécifique
     */
    public void purgeOperationChain(String chainId, String version, ExecutionMode mode) {
        String cacheKey = buildCacheKey(chainId, version, mode);

        cacheLock.writeLock().lock();
        try {
            cache.remove(cacheKey);
            ClassLoaderRegistry.getInstance().unregisterClassLoader(chainId, version, mode);
        } finally {
            cacheLock.writeLock().unlock();
        }
    }

    /**
     * Purge toutes les chaînes d'opération d'un identifiant donné
     */
    public void purgeAllVersions(String chainId) {
        cacheLock.writeLock().lock();
        try {
            List<String> keysToRemove = new ArrayList<>();
            cache.keySet().stream()
                    .filter(key -> key.startsWith(chainId + ":"))
                    .forEach(keysToRemove::add);

            keysToRemove.forEach(cache::remove);
            ClassLoaderRegistry.getInstance().unregisterAllVersions(chainId);
        } finally {
            cacheLock.writeLock().unlock();
        }
    }

    /**
     * Vide complètement le cache
     */
    public void clearCache() {
        cacheLock.writeLock().lock();
        try {
            cache.clear();
            ClassLoaderRegistry.getInstance().clear();
        } finally {
            cacheLock.writeLock().unlock();
        }
    }

    /**
     * Retourne les statistiques du cache
     */
    public CacheStatistics getCacheStatistics() {
        cacheLock.readLock().lock();
        try {
            int totalEntries = cache.size();
            long expiredEntries = cache.values().stream()
                    .mapToLong(cached -> cached.isExpired() ? 1 : 0)
                    .sum();

            return new CacheStatistics(totalEntries, (int) expiredEntries);
        } finally {
            cacheLock.readLock().unlock();
        }
    }

    private String buildCacheKey(String chainId, String version, ExecutionMode mode) {
        return String.format("%s:%s:%s", chainId, version, mode);
    }

    /**
     * Mode d'exécution
     */
    public enum ExecutionMode {
        TEST, RUN
    }

    /**
     * Exception spécifique aux chaînes d'opération
     */
    public static class OperationChainException extends Exception {
        public OperationChainException(String message) {
            super(message);
        }

        public OperationChainException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * Représente une chaîne d'opération mise en cache
     */
    private static class CachedOperationChain {
        private final Object instance;
        private final String chainId;
        private final String version;
        private final ExecutionMode mode;
        private final LocalDateTime creationTime;
        private final long ttlMinutes;

        public CachedOperationChain(Object instance, String chainId, String version,
                                    ExecutionMode mode, LocalDateTime creationTime) {
            this.instance = instance;
            this.chainId = chainId;
            this.version = version;
            this.mode = mode;
            this.creationTime = creationTime;
            this.ttlMinutes = mode == ExecutionMode.RUN ? 60 : 10; // TTL différent selon le mode
        }

        public Object getInstance() {
            return instance;
        }

        public boolean isExpired() {
            return LocalDateTime.now().isAfter(creationTime.plusMinutes(ttlMinutes));
        }
    }

    /**
     * Statistiques du cache
     */
    public static class CacheStatistics {
        private final int totalEntries;
        private final int expiredEntries;

        public CacheStatistics(int totalEntries, int expiredEntries) {
            this.totalEntries = totalEntries;
            this.expiredEntries = expiredEntries;
        }

        public int getTotalEntries() { return totalEntries; }
        public int getExpiredEntries() { return expiredEntries; }
        public int getValidEntries() { return totalEntries - expiredEntries; }
    }
}