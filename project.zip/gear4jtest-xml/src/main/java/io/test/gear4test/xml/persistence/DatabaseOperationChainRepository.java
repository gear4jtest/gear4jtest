package io.test.gear4test.xml.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;

import io.test.gear4test.xml.manager.AssemblyLineManager.ExecutionMode;

/**
 * Implémentation de repository en base de données
 */
public class DatabaseOperationChainRepository implements OperationChainRepository {
    
    private final DataSource dataSource;
    
    public DatabaseOperationChainRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    @Override
    public Optional<String> getOperationChainXml(String chainId, String version, ExecutionMode mode) {
        String sql = "SELECT xml_content FROM operation_chains WHERE chain_id = ? AND version = ? AND mode = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, chainId);
            stmt.setString(2, version);
            stmt.setString(3, mode.name());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(rs.getString("xml_content"));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de la chaîne d'opération", e);
        }
        
        return Optional.empty();
    }
    
    @Override
    public void saveOperationChain(String chainId, String version, ExecutionMode mode, String xmlContent) {
        String sql = """
            INSERT INTO operation_chains (chain_id, version, mode, xml_content, created_at, updated_at)
            VALUES (?, ?, ?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE xml_content = VALUES(xml_content), updated_at = NOW()
            """;
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, chainId);
            stmt.setString(2, version);
            stmt.setString(3, mode.name());
            stmt.setString(4, xmlContent);
            
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la sauvegarde de la chaîne d'opération", e);
        }
    }
    
    @Override
    public boolean deleteOperationChain(String chainId, String version, ExecutionMode mode) {
        String sql = "DELETE FROM operation_chains WHERE chain_id = ? AND version = ? AND mode = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, chainId);
            stmt.setString(2, version);
            stmt.setString(3, mode.name());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de la chaîne d'opération", e);
        }
    }
    
    @Override
    public List<String> getVersions(String chainId, ExecutionMode mode) {
        String sql = "SELECT version FROM operation_chains WHERE chain_id = ? AND mode = ? ORDER BY version";
        List<String> versions = new ArrayList<>();
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, chainId);
            stmt.setString(2, mode.name());
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    versions.add(rs.getString("version"));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des versions", e);
        }
        
        return versions;
    }
}
