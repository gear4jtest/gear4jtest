package io.test.gear4test.xml.persistence;

import java.util.ArrayList;
import java.util.List;

public class JavaOperationChainCode {
    private final String className;
    private final String sourceCode;
    private final List<String> dependencies;
    
    public JavaOperationChainCode(String className, String sourceCode, List<String> dependencies) {
        this.className = className;
        this.sourceCode = sourceCode;
        this.dependencies = new ArrayList<>(dependencies);
    }
    
    public String getClassName() { return className; }
    public String getSourceCode() { return sourceCode; }
    public List<String> getDependencies() { return new ArrayList<>(dependencies); }
}