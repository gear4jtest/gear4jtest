package io.test.gear4test.xml.persistence;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import io.test.gear4test.xml.manager.AssemblyLineManager.ExecutionMode;

public class InMemoryOperationChainRepository implements OperationChainRepository {
    
    private final Map<String, String> storage = new ConcurrentHashMap<>();
    
    @Override
    public Optional<String> getOperationChainXml(String chainId, String version, ExecutionMode mode) {
        String key = buildKey(chainId, version, mode);
        return Optional.ofNullable(storage.get(key));
    }
    
    @Override
    public void saveOperationChain(String chainId, String version, ExecutionMode mode, String xmlContent) {
        String key = buildKey(chainId, version, mode);
        storage.put(key, xmlContent);
    }
    
    @Override
    public boolean deleteOperationChain(String chainId, String version, ExecutionMode mode) {
        String key = buildKey(chainId, version, mode);
        return storage.remove(key) != null;
    }
    
    @Override
    public List<String> getVersions(String chainId, ExecutionMode mode) {
        String prefix = chainId + ":" + mode.name() + ":";
        return storage.keySet().stream()
            .filter(key -> key.startsWith(prefix))
            .map(key -> key.substring(prefix.length()))
            .sorted()
            .toList();
    }
    
    private String buildKey(String chainId, String version, ExecutionMode mode) {
        return String.format("%s:%s:%s", chainId, mode.name(), version);
    }
}