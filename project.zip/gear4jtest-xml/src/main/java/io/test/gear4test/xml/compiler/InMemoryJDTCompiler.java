//package io.test.gear4test.xml.compiler;
//
//import org.eclipse.jdt.core.compiler.batch.BatchCompiler;
//import org.eclipse.jdt.internal.compiler.batch.CompilationUnit;
//
//import java.io.*;
//import java.util.*;
//import java.util.concurrent.ConcurrentHashMap;
//
//public class InMemoryJDTCompiler {
//
//    private final Map<String, byte[]> compiledClasses = new ConcurrentHashMap<>();
//    private final InMemoryClassLoader classLoader;
//    private final Map<String, String> sources = new HashMap<>();
//
//    public InMemoryJDTCompiler() {
//        this.classLoader = new InMemoryClassLoader();
//    }
//
//    /**
//     * Compile avec JDT BatchCompiler - version 100% en mémoire
//     */
//    public boolean compileFromString(String className, String sourceCode) {
//        try {
//            // Stocker le source en mémoire
//            sources.put(className, sourceCode);
//
//            // Créer les unités de compilation en mémoire
//            List<CompilationUnit> units = new ArrayList<>();
//
//            for (Map.Entry<String, String> entry : sources.entrySet()) {
//                String clsName = entry.getKey();
//                String srcCode = entry.getValue();
//
//                // Créer le nom de fichier
//                String fileName = clsName.replace('.', '/') + ".java";
//
//                // Créer l'unité de compilation JDT
//                CompilationUnit unit = new CompilationUnit(
//                    srcCode.toCharArray(),
//                    fileName,
//                    "UTF-8"
//                );
//                units.add(unit);
//            }
//
//            // Préparer les arguments pour BatchCompiler
//            String[] args = buildCompilerArguments();
//
//            // Capturer la sortie dans des buffers
//            StringWriter errorOutput = new StringWriter();
//            StringWriter standardOutput = new StringWriter();
//            PrintWriter errorWriter = new PrintWriter(errorOutput);
//            PrintWriter outWriter = new PrintWriter(standardOutput);
//
//            // Créer un requestor personnalisé pour capturer les classes compilées
//            InMemoryCompilerRequestor requestor = new InMemoryCompilerRequestor();
//
//            // Compilation avec BatchCompiler
//            boolean success = BatchCompiler.compile(
//                units.toArray(new CompilationUnit[0]),
//                args,
//                outWriter,
//                errorWriter,
//                null, // progress
//                requestor
//            );
//
//            // Vérifier les erreurs
//            if (!success) {
//                System.err.println("Erreurs de compilation:");
//                System.err.println(errorOutput.toString());
//                if (requestor.hasErrors()) {
//                    requestor.getErrors().forEach(System.err::println);
//                }
//                return false;
//            }
//
//            // Récupérer les classes compilées
//            Map<String, byte[]> compiled = requestor.getCompiledClasses();
//            compiledClasses.putAll(compiled);
//
//            // Ajouter au ClassLoader
//            for (Map.Entry<String, byte[]> entry : compiled.entrySet()) {
//                classLoader.addCompiledClass(entry.getKey(), entry.getValue());
//                System.out.println("Classe compilée: " + entry.getKey());
//            }
//
//            return true;
//
//        } catch (Exception e) {
//            System.err.println("Erreur de compilation: " + e.getMessage());
//            e.printStackTrace();
//            return false;
//        }
//    }
//
//    /**
//     * Compile plusieurs classes en une seule fois
//     */
//    public boolean compileFromStrings(Map<String, String> classNameToSourceCode) {
//        sources.clear();
//        sources.putAll(classNameToSourceCode);
//
//        // On peut appeler compileFromString avec n'importe quelle classe
//        // car elle va compiler toutes les sources stockées
//        return compileFromString(classNameToSourceCode.keySet().iterator().next(), "");
//    }
//
//    /**
//     * Construit les arguments pour le BatchCompiler
//     */
//    private String[] buildCompilerArguments() {
//        List<String> args = new ArrayList<>();
//
//        // Version Java
//        args.add("-source");
//        args.add("17");
//        args.add("-target");
//        args.add("17");
//
//        // Encodage
//        args.add("-encoding");
//        args.add("UTF-8");
//
//        // Classpath (inclut le classpath système)
//        args.add("-classpath");
//        args.add(System.getProperty("java.class.path"));
//
//        // Options supplémentaires
//        args.add("-nowarn");  // Désactiver les warnings
//        args.add("-g");       // Générer les infos de debug
//
//        return args.toArray(new String[0]);
//    }
//
//    /**
//     * Requestor personnalisé pour capturer les classes compilées
//     */
//    private static class InMemoryCompilerRequestor implements org.eclipse.jdt.internal.compiler.ICompilerRequestor {
//        private final Map<String, byte[]> compiledClasses = new HashMap<>();
//        private final List<String> errors = new ArrayList<>();
//
//        @Override
//        public void acceptResult(org.eclipse.jdt.internal.compiler.CompilationResult result) {
//            if (result.hasErrors()) {
//                for (var problem : result.getAllProblems()) {
//                    errors.add(problem.getMessage());
//                }
//            } else {
//                // Récupérer les fichiers de classe générés
//                var classFiles = result.getClassFiles();
//                for (var classFile : classFiles) {
//                    // Construire le nom complet de la classe
//                    char[][] compoundName = classFile.getCompoundName();
//                    String className = String.join(".",
//                        Arrays.stream(compoundName)
//                            .map(String::new)
//                            .toArray(String[]::new));
//
//                    compiledClasses.put(className, classFile.getBytes());
//                }
//            }
//        }
//
//        public boolean hasErrors() {
//            return !errors.isEmpty();
//        }
//
//        public List<String> getErrors() {
//            return errors;
//        }
//
//        public Map<String, byte[]> getCompiledClasses() {
//            return compiledClasses;
//        }
//    }
//
//    /**
//     * ClassLoader personnalisé
//     */
//    private static class InMemoryClassLoader extends ClassLoader {
//        private final Map<String, byte[]> classes = new ConcurrentHashMap<>();
//
//        public InMemoryClassLoader() {
//            super(ClassLoader.getSystemClassLoader());
//        }
//
//        public void addCompiledClass(String className, byte[] classBytes) {
//            classes.put(className, classBytes);
//        }
//
//        @Override
//        protected Class<?> findClass(String name) throws ClassNotFoundException {
//            byte[] bytes = classes.get(name);
//            if (bytes == null) {
//                throw new ClassNotFoundException("Classe non trouvée: " + name);
//            }
//            return defineClass(name, bytes, 0, bytes.length);
//        }
//
//        @Override
//        protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
//            if (classes.containsKey(name)) {
//                Class<?> clazz = findLoadedClass(name);
//                if (clazz == null) {
//                    clazz = findClass(name);
//                }
//                if (resolve) {
//                    resolveClass(clazz);
//                }
//                return clazz;
//            }
//            return super.loadClass(name, resolve);
//        }
//    }
//
//    // Méthodes utilitaires
//    public Class<?> loadClass(String className) throws ClassNotFoundException {
//        return classLoader.loadClass(className);
//    }
//
//    public Object createInstance(String className) throws Exception {
//        Class<?> clazz = loadClass(className);
//        return clazz.getDeclaredConstructor().newInstance();
//    }
//
//    public byte[] getCompiledBytes(String className) {
//        return compiledClasses.get(className);
//    }
//
//    public Map<String, byte[]> getAllCompiledClasses() {
//        return new HashMap<>(compiledClasses);
//    }
//
//    /**
//     * Vide le cache des sources et classes compilées
//     */
//    public void clear() {
//        sources.clear();
//        compiledClasses.clear();
//    }
//
//    /**
//     * Méthode de test
//     */
//    public static void main(String[] args) {
//        InMemoryJDTCompiler compiler = new InMemoryJDTCompiler();
//
//        String testCode = """
//                package test.example;
//
//                public class TestClass {
//                    private String message = "Hello from JDT in-memory compilation!";
//
//                    public String getMessage() {
//                        return message;
//                    }
//
//                    public void setMessage(String message) {
//                        this.message = message;
//                    }
//
//                    public void processData() {
//                        // Utilise des classes Java standard pour tester le classpath
//                        java.util.List<String> list = new java.util.ArrayList<>();
//                        list.add("Test");
//                        System.out.println("Liste créée avec " + list.size() + " éléments");
//                    }
//                }
//                """;
//
//        try {
//            boolean success = compiler.compileFromString("test.example.TestClass", testCode);
//            System.out.println("Compilation réussie: " + success);
//
//            if (success) {
//                Object instance = compiler.createInstance("test.example.TestClass");
//                System.out.println("Instance créée: " + instance.getClass().getName());
//
//                // Test d'invocation de méthode
//                var method = instance.getClass().getMethod("getMessage");
//                String result = (String) method.invoke(instance);
//                System.out.println("Message: " + result);
//
//                // Test avec classes Java standard
//                var processMethod = instance.getClass().getMethod("processData");
//                processMethod.invoke(instance);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}