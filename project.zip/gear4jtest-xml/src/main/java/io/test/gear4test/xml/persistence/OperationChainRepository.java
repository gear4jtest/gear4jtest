package io.test.gear4test.xml.persistence;

import java.util.List;
import java.util.Optional;

import io.test.gear4test.xml.manager.AssemblyLineManager.ExecutionMode;

public interface OperationChainRepository {
    
    /**
     * Récupère le contenu XML d'une chaîne d'opération
     */
    Optional<String> getOperationChainXml(String chainId, String version, ExecutionMode mode);
    
    /**
     * Sauvegarde une chaîne d'opération
     */
    void saveOperationChain(String chainId, String version, ExecutionMode mode, String xmlContent);
    
    /**
     * Supprime une chaîne d'opération
     */
    boolean deleteOperationChain(String chainId, String version, ExecutionMode mode);
    
    /**
     * Liste toutes les versions d'une chaîne d'opération
     */
    List<String> getVersions(String chainId, ExecutionMode mode);
}