# @gear4j/studio-web — expérimental 0.6.2

Composants publics ESM et Web Components, sans dépendance au module de démonstration.
Le serveur Java et la démo Spring consomment ces mêmes sources via processResources.

```sh
npm ci
npm test
npm run pack:check
npm pack
```

Installer le .tgz produit dans un portail (`npm install /chemin/gear4j-studio-web-0.6.2.tgz`).
Importer `ManagementClient` depuis `@gear4j/studio-web/client`, `Gear4jStudio` depuis
`@gear4j/studio-web/editor`, ou `Gear4jWorkspace` depuis `@gear4j/studio-web/workspace`.
L’entrée principale enregistre les Web Components ; l’entrée client fonctionne sans DOM.
Pas de bundler imposé ; un portail peut servir les fichiers ESM de src sous un même répertoire.
Les navigateurs doivent disposer de Web Components, structuredClone et crypto.randomUUID.

```js
import { ManagementClient } from '@gear4j/studio-web/client';
import '@gear4j/studio-web/workspace';
await document.querySelector('gear4j-workspace').configure({
  client: new ManagementClient({ baseUrl: '', tokenProvider: () => tokenDeSession })
});
```

L’hôte fournit l’authentification. Aucun stockage du token, aucune relance automatique de POST.
Pour l’éditeur seul : récupérer le draft avec ManagementClient, construire ScopedAuthoringClient,
puis appeler configure({client: scoped, revision: scoped.flat(state)}).
Les événements studio:revision / studio:run contiennent uniquement les identifiants et statuts.
Consulter ../docs/studio/p6.md pour les contrats, limites et changements d’API.


Le composant de cycle de vie est également consommable séparément :

```js
import '@gear4j/studio-web/versions';
await document.querySelector('gear4j-versions').configure({
  client,
  chainId
});
```

Pour figer depuis un éditeur, fournir `canFreeze` obtenu depuis les permissions
PUBLISH de la chaîne et `getDraft: () => ({ revision: editor.revision,
dirty: editor.hasUnsavedChanges })`. Ces informations ne remplacent jamais les
contrôles serveur. Le composant refuse de figer une SOURCE ou des modifications
locales non enregistrées. Publication TEST et promotion RUN sont distinctes ;
les reprises nécessitent une action explicite après lecture de l’état.
Les scripts sont servis ensemble (dont `studio-versions.mjs`) par les démos.

L’exploitation est également un composant public autonome :

```js
import '@gear4j/studio-web/runs';
await document.querySelector('gear4j-runs').configure({
  client,
  scopeId: chainId, // ou draftId
  canReadRuns: permissions.includes('READ_RUNS'),
  canReadObservability: permissions.includes('READ_OBSERVABILITY')
});
```

Le serveur vérifie toujours les droits courants. La sélection d’un run émet
`studio:run` avec l’identifiant d’observation Studio et son statut ; l’identifiant
Gear4J figure dans son détail. Aucun payload ne voyage dans cet événement DOM.
L’actualisation automatique est opt-in : snapshots SSE avec Authorization en
header, relecture du snapshot après fermeture, polling à défaut. Aucun event log
ni replay durable n’est supposé. Le retrait du composant arrête le suivi ; une
réponse 401/403/404 efface les données affichées. Les requêtes sont exclusivement
des GET : ce composant ne peut pas lancer ou répéter une exécution.


Les scénarios sont également disponibles seuls :

```js
import '@gear4j/studio-web/scenarios';
await document.querySelector('gear4j-scenarios').configure({
  client,
  scopes: [{ id: draftId, label: 'Draft privé', permissions }],
  getTargets: () => [{
    key: editor.revision.revisionId,
    label: `Draft · révision ${editor.revision.number}`,
    target: { draftId, revision: editor.revision.number },
    disabled: editor.hasUnsavedChanges || editor.revision.kind === 'SOURCE'
  }]
});
```

Pour une version figée, fournir `target: { versionId }` avec clé/étiquette
correspondantes. Les scopes et permissions viennent du serveur, qui recontrôle
chaque opération. Un scénario de draft reste limité à ce draft.
`studio:scenario` émet seulement id/révision après sauvegarde ; `studio:run`
émet requestId/état après soumission. `hasUnsavedChanges` protège la navigation.
Le reçu est relu par GET après une réponse perdue, sans répétition du POST.
Les données sont persistées après admission par ScenarioDataPolicy.

Les indicateurs regroupent les stations par nodeId et dimensions de version,
mode, artefact, catalogue et build, affichées dans chaque ligne. staleAt signale
une observation ancienne sans changer le résultat métier.

Le sélecteur fédéré emploie ces mêmes composants :

```js
import { FederationClient } from '@gear4j/studio-web/targets';
await document.querySelector('gear4j-targets').configure({
  client: new FederationClient({ baseUrl: '', tokenProvider: () => tokenDeSession })
});
```

Le serveur publie l’inventaire autorisé et relaie les routes sous
`/targets/{id}/api/v1`. Le navigateur ne choisit pas d’URL distante et ne fournit
jamais l’identité de l’acteur. Un nouveau workspace est créé à chaque changement
de cible. `hasUnsavedChanges` couvre drafts, scénarios, formulaires et ACL ; une
action en cours bloque le changement de cible. Après confirmation d’abandon,
aucune saisie locale n’est transférée à la cible suivante.

`studio:target` expose `{ targetId, runtimeContextId }`. `studio:disconnect`
signale à l’hôte qu’il doit vider sa session ; le composant vide son affichage.
Le launcher P5 conserve son token en mémoire uniquement. Une réponse perdue
après mutation reste `REMOTE_OUTCOME_UNKNOWN`, sans retry automatique. Le suivi
des runs passe par le polling existant si la passerelle ne relaie pas SSE.

La simulation est intégrée aux scénarios avec `simulationEnabled: true` obtenu
des capabilities du contexte et `getTargets(action)` filtré selon TEST ou SIMULATE.
Fournir `definition` dans une cible de draft pour préparer automatiquement ses
nœuds ; les substitutions commencent en FAIL, puis sont configurées explicitement.
Les mocks sont sauvegardés dans `ScenarioData.simulation`, avec la révision.

Le composant peut aussi être intégré directement :

```js
import '@gear4j/studio-web/simulation';
document.querySelector('gear4j-simulation').configure({
  client, scenarioId, revision, profile, editable,
  getTargets: () => simulationTargets,
  unsaved: () => scenarioHasLocalChanges,
  onChange: profile => updateScenarioForm(profile)
});
```

Le portail doit enregistrer le profil via les APIs de scénario avant simulation.
`busy` bloque sa navigation pendant une requête. `studio:simulation` émet
uniquement `{ id }`, sans payload. Le rapport porte des résultats synthétiques
et ne remplace pas un test contrôlé. Après réponse perdue, relire GET simulation
avec le requestId conservé ; aucun retry automatique du POST. `onUnavailable`
permet au portail d’effacer son état privé après un refus d’accès.

Les rapports de simulation se consultent avec `READ_SIMULATIONS` sur leur cible
et `READ_SCENARIOS` sur le scénario ; `READ_RUNS` ne les autorise pas. Les captures
restent conditionnées à `READ_OBSERVABILITY`. Le composant affiche les diagnostics
`HISTORICAL_CONTEXT_DIFFERS` du plan et du rapport, y compris après relecture :
une ancienne version utilise le simulateur et le catalogue actuels.
