package io.github.gear4jtest.core.model.refactor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import io.github.gear4jtest.core.model.refactor.ProcessingOperationDefinition.ParameterModel;

public class OperationParamsInjector implements Processor {

	@Override
	public void beforeExecution(Object input, OperationExecutionContext operationExecution) {
		var processingParameters = OperationContextUtils.getProcessingParameters(operationExecution);
		var transformer = OperationContextUtils.getRawTransformer(operationExecution);
		if (processingParameters.isEmpty() || transformer.isEmpty()) {
			return;
		}

		for (ParameterModel<?, ?> rawParam : processingParameters.get().getParameters()) {
			injectParameter(rawParam, transformer.get(), input);
		}
	}

	/**
	 * On centralise ici le cast "unsafe" entre le transformer et le modèle de
	 * paramètre. La cohérence est déjà assurée au moment de la définition
	 * (Builder.parameter(...)), donc on peut raisonnablement faire ce cast.
	 */
	@SuppressWarnings("unchecked")
	private <IN, OUT, OP extends Transformer<IN, OUT>, T> void injectParameter(
			ParameterModel<?, ?> rawParam,
			Transformer<?, ?> rawTransformer,
			Object input) {

		// Récupération typée
		ParameterModel<OP, T> param = (ParameterModel<OP, T>) rawParam;
		OP op = (OP) rawTransformer;

		OperationParamsInjector.Parameter<T> parameterValue =
				param.getParamRetriever().getParameterValue(op);

		if (parameterValue == null) {
			return;
		}

		T value = param.getValue(input);
		parameterValue.setValue(value);

		// Event à réactiver si besoin :
		// context.getEventTriggerService()
		//        .publishEvent(new ParameterInjectionEventBuilder()
		//        .buildEvent(context.getId(), buildParameterContextualData(value)));
	}

	// ------------------------------------------------------------------------
	// Parameters : container pour les modèles de paramètres
	// ------------------------------------------------------------------------

	public static class Parameters {

		private final List<ParameterModel<?, ?>> parameters;

		public Parameters() {
			this.parameters = new ArrayList<>();
		}

		public boolean hasParameters() {
			return !this.parameters.isEmpty();
		}

		public List<ParameterModel<?, ?>> getParameters() {
			return parameters;
		}

		public static Builder newBuilder() {
			return new Builder();
		}

		public static class Builder {

			private final Parameters instance = new Parameters();

			public Builder withParameter(ParameterModel<?, ?> parameter) {
				instance.parameters.add(parameter);
				return this;
			}

			public Builder withParameters(Optional<Parameters> parameters) {
				parameters.ifPresent(p -> instance.parameters.addAll(p.parameters));
				return this;
			}

			public Parameters build() {
				return instance;
			}
		}
	}

	// ------------------------------------------------------------------------
	// Parameter<T> : handle côté opération (read-only pour le transformer)
	// ------------------------------------------------------------------------

	public static class Parameter<T> {

		private T value;

		private Parameter() {
		}

		private Parameter(T value) {
			this.value = value;
		}

		/**
		 * Paramètre sans valeur par défaut (sera alimenté uniquement par l'injecteur).
		 */
		public static <T> Parameter<T> of() {
			return new Parameter<>();
		}

		/**
		 * Paramètre avec valeur par défaut. Utile si l'opération est appelée en dehors
		 * du pipeline, ou si aucun param n'a été défini pour cette opération.
		 */
		public static <T> Parameter<T> ofDefault(T defaultValue) {
			return new Parameter<>(defaultValue);
		}

		public T getValue() {
			return value;
		}

		// package-private : seul l'injecteur (même package) peut modifier la valeur
		void setValue(T value) {
			this.value = value;
		}
	}
}
