package io.github.gear4jtest.core.model.refactor;

/**
 * Un processor qui intervient avant l'exécution de l'opération.
 * (Tu peux ajouter afterExecution plus tard si besoin.)
 */
@FunctionalInterface
public interface Processor {

	<I> void beforeExecution(I input, OperationExecutionContext ctx) throws Exception;
}